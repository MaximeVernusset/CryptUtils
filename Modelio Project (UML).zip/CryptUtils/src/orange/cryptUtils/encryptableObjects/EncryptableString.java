package orange.cryptUtils.encryptableObjects;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4d4e1f4d-180f-4c41-b35a-ab504df81368")
public class EncryptableString implements Encryptable {
    @objid ("444f3991-1a52-4d58-816e-ebc999fe9304")
    private static final long serialVersionUID;

    @objid ("1503b660-2114-4d3b-8729-6b0c94f21062")
    public String string;

    @objid ("ea93feae-eb3c-4ebd-ae2a-e1e237bb8126")
    public EncryptableString(String p0) {
    }

    @objid ("5725d250-6fef-4f3e-be45-75ed8343cba2")
    public boolean equals(Object p0) {
    }

    @objid ("4f206c2f-3af6-4ca3-8689-49717da8672e")
    public String toString() {
    }

    @objid ("a9428de8-ecad-4c5f-89be-01e64d9556a8")
    public String getString() {
    }

    @objid ("07683530-ff60-49a2-b119-13412695be39")
    public void setString(String p0) {
    }

}
