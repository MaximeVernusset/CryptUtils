package orange.cryptUtils.encryptableObjects;

import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("97306437-c8d4-469a-b23e-fea717d09745")
public interface Encryptable extends Serializable {
    @objid ("89cf6f6b-25b0-41d7-b676-8e17ba6d40c0")
    boolean equals(Object p0);

    @objid ("2b4c6663-4ad3-4743-91b9-1eacd1560b48")
    String toString();

}
