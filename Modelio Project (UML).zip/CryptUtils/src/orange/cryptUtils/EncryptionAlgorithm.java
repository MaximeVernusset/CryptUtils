package orange.cryptUtils;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("fe8b2c4e-af5b-4a62-8cd5-ad0efb8baa3a")
public interface EncryptionAlgorithm {
    @objid ("7a97a829-4272-4937-99ae-810e9e7e33c0")
    String toString();

    @objid ("5c8c390a-d0bc-4c8e-94ac-def1209b20d5")
    String getName();

    @objid ("7a948ff4-e58e-4b46-a73d-78f65d7bb8d8")
    int getKeySize();

    @objid ("3357e394-1de7-4961-afa5-07e0ea9bc89e")
    String getAlgo();

}
