package orange.cryptUtils.exceptions;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ed48a44e-dfd9-49a9-91ca-3f8ec4b0d63d")
public class WrongSymmetricKeySizeException extends Exception {
    @objid ("64d419e2-89c4-4c09-a825-f7e400d521b6")
    private static final long serialVersionUID;

    @objid ("5bbb173e-37b0-4a0f-b0cc-84c737fce8b6")
    public WrongSymmetricKeySizeException(int p0, int p1) {
    }

}
