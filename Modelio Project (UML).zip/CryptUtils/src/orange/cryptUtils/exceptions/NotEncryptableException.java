package orange.cryptUtils.exceptions;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("66857187-7f59-43de-ab6b-6c5275d15058")
public class NotEncryptableException extends Exception {
    @objid ("d1d7b9fc-dcd3-4e60-a1c7-e744fbc34ae0")
    private static final long serialVersionUID;

    @objid ("bed16f52-cad4-48a7-b723-a746858d80f4")
    public NotEncryptableException() {
    }

}
