package orange.cryptUtils.exceptions;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("055b3d89-4c34-4978-bdb9-21e115f89716")
public abstract class ConflictingEncryptionAlgorithmsException extends Exception {
    @objid ("72cf638f-d63c-4fee-9146-29164300fd8b")
    private static final long serialVersionUID;

    @objid ("bed12f20-54d4-4235-8efc-ceeab0cdd470")
    public ConflictingEncryptionAlgorithmsException(String p0) {
    }

}
