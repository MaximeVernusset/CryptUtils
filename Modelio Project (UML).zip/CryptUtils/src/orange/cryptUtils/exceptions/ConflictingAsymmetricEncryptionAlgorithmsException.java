package orange.cryptUtils.exceptions;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("245d7b60-55c6-412e-8b30-ebcfc9cf0d24")
public class ConflictingAsymmetricEncryptionAlgorithmsException extends ConflictingEncryptionAlgorithmsException {
    @objid ("043cbf71-55bd-4c59-ab6d-3c02b77440a1")
    private static final long serialVersionUID;

    @objid ("4d68f0ba-43ba-457d-a3bb-cfd13970221b")
    public ConflictingAsymmetricEncryptionAlgorithmsException(String p0) {
    }

    @objid ("900d0983-c322-45a7-bbe8-0f3d4118dccc")
    public ConflictingAsymmetricEncryptionAlgorithmsException(String p0, String p1, String p2) {
    }

}
