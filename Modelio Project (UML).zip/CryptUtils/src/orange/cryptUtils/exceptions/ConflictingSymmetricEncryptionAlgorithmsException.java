package orange.cryptUtils.exceptions;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("dae9ec9d-9c87-4d61-ab07-aa1e1550fc0c")
public class ConflictingSymmetricEncryptionAlgorithmsException extends ConflictingEncryptionAlgorithmsException {
    @objid ("93e081e8-099f-493d-8ea6-ac6a44fa64ff")
    private static final long serialVersionUID;

    @objid ("e0288690-5bd8-4ffe-b35b-76dc4a105ce8")
    public ConflictingSymmetricEncryptionAlgorithmsException(String p0, String p1) {
    }

}
