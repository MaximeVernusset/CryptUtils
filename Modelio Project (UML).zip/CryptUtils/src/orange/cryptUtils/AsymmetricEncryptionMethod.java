package orange.cryptUtils;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import orange.cryptUtils.encryptableObjects.Encryptable;
import orange.cryptUtils.exceptions.ConflictingAsymmetricEncryptionAlgorithmsException;
import orange.cryptUtils.exceptions.NotEncryptableException;

@objid ("cb2f9211-e222-4cbb-84f2-7c40b0e95d59")
public class AsymmetricEncryptionMethod extends EncryptionMethod {
    @objid ("92c238df-1a93-4b51-944b-3895fe3494f4")
    protected KeyPair keyPair;

    @objid ("e049d160-9781-4d24-a68f-e6d56cc7776d")
    protected PublicKey correspondentPublicKey;

    @objid ("9c22a9fa-fd37-4d0b-861e-4e0f0596dfbb")
    public AsymmetricEncryptionMethod(Algorithm p0, KeyPair p1, PublicKey p2) throws ConflictingAsymmetricEncryptionAlgorithmsException {
    }

    @objid ("c676a5a0-2a1a-41b1-8f77-340af2ebcb11")
    protected byte[] encrypt(Encryptable p0) throws BadPaddingException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("a065063a-4c03-4819-9293-abc5143db3f7")
    protected Encryptable decrypt(byte[] p0) throws BadPaddingException, ClassNotFoundException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("c62563b9-90c0-49c1-a6a1-0c6d66f5219d")
    public PublicKey getPublicKey() {
    }

    @objid ("e26ae3ae-14ba-4863-97e5-0f3226ed6e5b")
    public static KeyPair buildKeyPair(Algorithm p0) {
    }

    @objid ("87f044f3-0bba-452b-9ca0-d263945b010e")
    public void setKeyPair(KeyPair p0) {
    }

    @objid ("a2bbdba9-3b44-43bd-accd-d0d064f88555")
    protected PrivateKey getPrivateKey() {
    }

    @objid ("e65674c0-9462-43a1-ad96-f49db14f9bf4")
    public String encryptToBase64String(Encryptable p0) throws BadPaddingException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("4d32794d-75aa-40d6-bbe0-b3004efa0bd6")
    public PublicKey getCorrespondentPublicKey() {
    }

    @objid ("39b05c7f-7660-40c6-a091-f54ad676ec80")
    public Encryptable decryptFromBase64String(String p0) throws BadPaddingException, ClassNotFoundException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("fb67c945-867b-477d-a4e5-2d76dcb06309")
    public byte[] encryptToBytesArray(Encryptable p0) throws BadPaddingException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("ccd946b4-308a-4098-aeb7-070a5fe12b58")
    public Encryptable decryptFromBytesArray(byte[] p0) throws BadPaddingException, ClassNotFoundException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("b5c35bf6-defa-4a8c-94cb-cdb6027b893b")
    public void setCorrespondentPublicKey(PublicKey p0) {
    }

    @objid ("4c9c9083-93d5-472d-b9fd-739d16f806a8")
    public enum Algorithm {
        ;

        @objid ("1312438c-f09d-4c2e-a9ac-4850d13f0e53")
        private final String name;

        @objid ("65efb5fd-42d1-4ba1-b512-595e6ae724e2")
        private final int keySize;

        @objid ("eb613df2-adf5-4dd4-8c79-b165582d66b1")
        public static final Algorithm RSA_ECB_PKCS1Padding_1024;

        @objid ("5d809ca2-6938-4319-b390-481fc22d6989")
        public static final Algorithm RSA_ECB_PKCS1Padding_2048;

        @objid ("70b5241b-0701-43f6-a8f4-7992bbdc3a99")
        public static final Algorithm RSA_ECB_PKCS1Padding_3072;

        @objid ("51416dea-f0f3-43e4-bf93-0e86a1311f85")
        public static final Algorithm RSA_ECB_OAEPWithSHA_1AndMGF1Padding_1024;

        @objid ("17131c66-c0a8-4890-b694-444a7ae91307")
        public static final Algorithm RSA_ECB_OAEPWithSHA_1AndMGF1Padding_2048;

        @objid ("7d35f542-508d-415b-9b7f-435a9755febf")
        public static final Algorithm RSA_ECB_OAEPWithSHA_1AndMGF1Padding_3072;

        @objid ("4fc6ede4-c48e-487a-9380-a99a053b9dd8")
        public static final Algorithm RSA_ECB_OAEPWithSHA_256AndMGF1Padding_1024;

        @objid ("db31b0af-b8ff-4ec6-bd5d-92d7f8bc8dce")
        public static final Algorithm RSA_ECB_OAEPWithSHA_256AndMGF1Padding_2048;

        @objid ("c749eb2b-e107-4373-b901-2478b0aee37d")
        public static final Algorithm RSA_ECB_OAEPWithSHA_256AndMGF1Padding_3072;

        @objid ("ffa661bf-058a-4016-88a7-368bae69cc84")
        private static final Algorithm[] ENUM$VALUES;

        @objid ("f806a61a-6348-4e89-a9a7-ec3e48e1262d")
        private Algorithm(String p0, int p1, String p2, int p3) {
        }

        @objid ("c4db9578-6b1b-4b51-80d1-4041b0a8103c")
        public String toString() {
        }

        @objid ("ec1a5914-5eff-4b99-8e77-1736da7ec881")
        public static Algorithm[] values() {
        }

        @objid ("c255f4bf-b0e8-4d16-9331-b0ba6592a1b2")
        public static Algorithm valueOf(String p0) {
        }

        @objid ("03132a02-8b0f-448f-93bb-5b6821bee0e4")
        public String getName() {
        }

        @objid ("65245dcf-fba9-4f1c-a4c9-c33c0f6d7e64")
        public int getKeySize() {
        }

        @objid ("b3a56308-d242-46ec-b5bb-bf6f5404cc39")
        public String getAlgo() {
        }

    }

}
