package orange.cryptUtils;

import java.io.IOException;
import java.security.InvalidKeyException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import orange.cryptUtils.encryptableObjects.Encryptable;
import orange.cryptUtils.exceptions.NotEncryptableException;

@objid ("4cd8369a-a7a2-4a17-9467-c55bf3655bb5")
public abstract class EncryptionMethod {
    @objid ("22f06abf-5061-4291-90f4-1efb696fa315")
    protected Cipher cipher;

    @objid ("1de2817c-c68d-40c6-80cf-6f3b41ee5732")
    protected EncryptionMethod(EncryptionAlgorithm p0) {
    }

    @objid ("1bbfd773-8aa9-433d-8196-9cea222799e7")
    protected abstract byte[] encrypt(Encryptable p0) throws BadPaddingException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException;

    @objid ("037d2314-d8f6-4adb-b909-ea0458da74ce")
    protected abstract Encryptable decrypt(byte[] p0) throws BadPaddingException, ClassNotFoundException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException;

    @objid ("b9dadcec-2e60-4528-81ab-6fb7ab0138e3")
    protected byte[] serialize(Encryptable p0) throws IOException, NotEncryptableException {
    }

    @objid ("45a91305-9682-4b53-82a5-d9ec41caf864")
    protected Encryptable deserialize(byte[] p0) throws ClassNotFoundException, IOException, NotEncryptableException {
    }

    @objid ("76d474d5-74b0-43cb-a6d3-57f20cf196a2")
    public abstract String encryptToBase64String(Encryptable p0) throws BadPaddingException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException;

    @objid ("28779561-de8c-45ea-865e-84d52343dd9c")
    public abstract Encryptable decryptFromBase64String(String p0) throws BadPaddingException, ClassNotFoundException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException;

    @objid ("936ac447-e1cf-46bf-a934-e5396862318a")
    public abstract byte[] encryptToBytesArray(Encryptable p0) throws BadPaddingException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException;

    @objid ("73a42f9f-a82b-4291-90b1-57a03cd08996")
    public abstract Encryptable decryptFromBytesArray(byte[] p0) throws BadPaddingException, ClassNotFoundException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException;

}
