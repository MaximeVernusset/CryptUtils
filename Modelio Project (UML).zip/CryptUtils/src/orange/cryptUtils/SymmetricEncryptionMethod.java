package orange.cryptUtils;

import java.io.IOException;
import java.security.InvalidKeyException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.SecretKey;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import orange.cryptUtils.encryptableObjects.Encryptable;
import orange.cryptUtils.exceptions.ConflictingSymmetricEncryptionAlgorithmsException;
import orange.cryptUtils.exceptions.NotEncryptableException;
import orange.cryptUtils.exceptions.WrongSymmetricKeySizeException;

@objid ("0874fabb-d90c-40c3-9a8c-bbefa56d53fb")
public class SymmetricEncryptionMethod extends EncryptionMethod {
    @objid ("fdcd9c37-3f9c-4635-89c1-38277e05a130")
    protected SecretKey key;

    @objid ("2cd7026e-e912-47af-ac73-cdcc69a27db1")
    public SymmetricEncryptionMethod(Algorithm p0, byte[] p1) throws WrongSymmetricKeySizeException {
    }

    @objid ("0c2cdcfc-0cc9-459c-9d01-ee0e179d5b1e")
    public SymmetricEncryptionMethod(Algorithm p0, SecretKey p1) throws ConflictingSymmetricEncryptionAlgorithmsException, WrongSymmetricKeySizeException {
    }

    @objid ("99b03b4e-4a84-4782-a8a8-a4affd7e4803")
    protected byte[] encrypt(Encryptable p0) throws BadPaddingException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("91304537-056a-480a-8cff-4f0f28d130f7")
    protected Encryptable decrypt(byte[] p0) throws BadPaddingException, ClassNotFoundException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("3f24456e-4018-4b89-b999-36efd9a1aa7e")
    public static SecretKey buildSecretKey(Algorithm p0) {
    }

    @objid ("6fa896ca-5a6a-4eb8-8edb-fd2551e9ef01")
    public String encryptToBase64String(Encryptable p0) throws BadPaddingException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("c676068b-5a26-4761-8dbb-c419465c7c52")
    public Encryptable decryptFromBase64String(String p0) throws BadPaddingException, ClassNotFoundException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("d78d2503-d594-47ef-b32b-d15d0856764b")
    public byte[] encryptToBytesArray(Encryptable p0) throws BadPaddingException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("375b4bd2-3a1d-4b78-bd8b-e57b3d72c330")
    public Encryptable decryptFromBytesArray(byte[] p0) throws BadPaddingException, ClassNotFoundException, IOException, IllegalBlockSizeException, InvalidKeyException, NotEncryptableException {
    }

    @objid ("0936c064-333b-4fb6-a805-539ee3738fef")
    public enum Algorithm {
        ;

        @objid ("7b4d48b2-20b3-4e50-a2d9-e4313cc04f83")
        private final String name;

        @objid ("05817a50-dd4d-4a0d-a8f0-4b3268fac0d9")
        private final int keySize;

        @objid ("603a8c2d-4298-4237-9518-ca4b1596f4a7")
        public static final Algorithm AES_ECB_PKCS5PADDING_128;

        @objid ("f19c9cce-4deb-48f9-94b5-49b3691e9e4a")
        public static final Algorithm AES_ECB_PKCS5PADDING_192;

        @objid ("08e64c9e-304b-4c26-9feb-600287da6e86")
        public static final Algorithm AES_ECB_PKCS5PADDING_256;

        @objid ("296e0f17-34e6-43d2-b461-d5cb49590a5d")
        private static final Algorithm[] ENUM$VALUES;

        @objid ("5ecbf424-e681-4897-816d-03f310c6d2f1")
        private Algorithm(String p0, int p1, String p2, int p3) {
        }

        @objid ("16eda8b4-892c-49ab-ad7f-73cb83b7fa43")
        public String toString() {
        }

        @objid ("05370ac3-950e-4af5-a94a-ec1833ad9d67")
        public static Algorithm[] values() {
        }

        @objid ("20aff686-3dc8-49b4-b7bd-72fcdfb15596")
        public static Algorithm valueOf(String p0) {
        }

        @objid ("38ecc987-56f9-459f-aa77-ce564ff1ff7b")
        public String getName() {
        }

        @objid ("efd561ce-5b49-49ea-ab79-35746d2f2e43")
        public int getKeySize() {
        }

        @objid ("b0c39da4-6755-48ff-a840-44bc58db05b0")
        public String getAlgo() {
        }

    }

}
